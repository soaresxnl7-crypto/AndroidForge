IRONTRACK — PACOTE WEB PARA ANDROIDFORGE

Conteúdo: index.html com a interface minimalista em preto e branco baseada na referência enviada, recursos já existentes do IronTrack, temporizador de descanso e cardio, fichas editáveis, histórico, calendário, estatísticas, supersets, recordes, modelos, medidas corporais e backup/importação.

Estrutura preparada para entrada como projeto web: index.html na raiz, manifest.json, sw.js e assets/.

Importante: o arquivo enviado New Folder.zip continha os assets web dentro de um pacote APK compilado, não o projeto Android nativo completo. Este ZIP é um pacote web organizado para ser enviado ao fluxo AndroidForge; a compilação final do APK precisa ser executada no AndroidForge/GitHub Actions.

Os dados são guardados localmente no aparelho. O pacote não apaga dados já existentes automaticamente; em uma instalação nova, o histórico começa vazio. Faça backup antes de substituir uma instalação existente.
