# IronTrack — Projeto Gradle com 15 telas

Este ZIP inclui um projeto Android Gradle e a interface web do IronTrack.

## 15 telas incluídas na camada visual
1. Splash
2. Login / perfil local
3. Início
4. Treinos
5. Detalhes do exercício
6. Registrar série
7. Temporizador de descanso
8. Temporizador de cardio
9. Histórico
10. Estatísticas
11. Tipos de cardio
12. Perfil
13. Configurações
14. Tela motivacional
15. Prévia de notificação

A grade “Prévia das 15 telas” abre as telas individualmente. As telas usam os registros e preferências locais disponíveis no aplicativo; login é apenas perfil local, e a notificação é uma prévia visual, não uma notificação de sistema real.

O projeto contém `settings.gradle`, `build.gradle`, `app/build.gradle`, manifesto Android, Activity WebView e os assets web em `app/src/main/assets/www`. A referência original fica em `reference/Painel-de-UI-15-telas.png`.

A validação executada cobre integridade do ZIP e sintaxe JavaScript. A compilação Android real ainda precisa ser testada no AndroidForge.
