# IronTrack — AndroidForge Gradle project

- Android project Gradle real na raiz (`settings.gradle`, `build.gradle`, `app/build.gradle`).
- Interface web original mantida e tema ajustado para preto/cinza/branco.
- Biblioteca de busca expandida para **325 exercícios**, incluindo variações por equipamento e exercícios de cardio.
- A ficha já permite adicionar, editar, remover e reordenar exercícios; a divisão permite renomear pelo botão de edição.
- Histórico de treinos começa vazio em uma instalação nova; o plano base é apenas um modelo editável, sem sessões concluídas de demonstração.
- A imagem enviada com as 15 telas está preservada em `reference/` como referência visual.

## Como usar
Envie este ZIP ao AndroidForge como fonte de um projeto Gradle. O projeto precisa resolver o plugin Android Gradle e Android SDK no ambiente de build.

## Limitações transparentes
O pacote foi validado estruturalmente e o ZIP passou no teste de integridade. A compilação Android real não foi executada neste ambiente. A imagem de referência não se transforma automaticamente em telas: o app mantém as telas e recursos existentes no HTML original e acrescenta a biblioteca ampliada.
