# Planejamento consolidado do IronTrack

## Marca e experiência inicial
- Nome: IRONTRACK.
- Ícone: apenas monograma IT, preto e branco.
- Abertura: animação curta, fundo preto, monograma e nome.
- Painel: saudação por horário/nome, treino do dia, retomada de treino em andamento e resumo real da evolução.

## Treino
- Manter ficha Push / Pull / Lower 1 / Upper / Lower 2, com quarta-feira como descanso, ajustável pelo usuário.
- Séries concluídas, cargas, repetições e cronômetro.
- Supersets: agrupar dois ou mais exercícios, mantendo dados separados.
- Notes: notas por exercício e sessão.
- Muscles: músculos principais/secundários por exercício.
- PR: recordes pessoais com valor anterior, novo valor, data e tipo.
- Templates: criar, editar, duplicar e aplicar modelos sem apagar histórico.

## Progresso
- Histórico, gráficos, calendário, medidas corporais, estatísticas e backup/restauração.
- Resultados derivados apenas dos dados registrados.

## Offline e nuvem
- Banco local como base para o treino offline.
- Fila de sincronização, IDs estáveis, deduplicação e resolução de conflitos.
- Backend recomendado: Supabase, após confirmar a tecnologia do projeto.
- Autenticação, políticas RLS e permissões por usuário.

## Social e Android
- Perfis e compartilhamento privado por padrão.
- Widgets nativos e atalhos Android exigem implementação nativa compatível.

## Exercícios
- Biblioteca planejada com 192 exercícios em português.
- Imagens individuais para cada exercício ficam adiadas, conforme orientação do usuário.

## Ordem de implementação
1. Auditoria e recuperação do projeto.
2. Modelo de dados e preservação/migração.
3. Supersets, notas, músculos, PR e templates.
4. Offline confiável.
5. Backend, autenticação e sincronização.
6. Social e privacidade.
7. Widgets nativos.
8. Testes Android e compilação final do APK.
