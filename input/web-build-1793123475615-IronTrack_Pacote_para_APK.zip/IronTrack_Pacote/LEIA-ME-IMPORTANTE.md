# IronTrack — pacote de projeto recuperado

## Conteúdo incluído
- `index.html`: interface web recuperada do APK enviado, com ajustes na marca e uma abertura animada curta com monograma IT.
- `assets/irontrack-icon.png`, `icon-192.png`, `icon-512.png`: ícone monocromático com apenas IT.
- `manifest.json` e `sw.js`: metadados de PWA e cache offline para hospedagem web compatível.
- `assets/capa-irontrack.png`: arte já presente no APK original.

## Recursos já presentes no código recuperado
- Fichas de treino editáveis e biblioteca de exercícios.
- Registro de séries, cargas e repetições.
- Cronômetro de descanso.
- Histórico, gráfico de volume, calendário e medidas corporais.
- Perfil local, exportação e importação de backup JSON.
- Persistência local via `localStorage`.

## Ajustes visuais deste pacote
- Monograma IT na marca da interface.
- Splash screen preta com IT branco, linha animada e nome IRONTRACK.
- Saudação baseada no horário e no primeiro nome salvo no perfil.
- Ícone de aplicativo monocromático em PNG.

## Ainda NÃO implementado / depende de desenvolvimento adicional
- Supersets funcionais completos.
- Anotações por exercício e por sessão.
- Mapeamento detalhado de músculos por exercício.
- Sistema completo de recordes pessoais (PR).
- Templates para criar, duplicar e aplicar fichas.
- Backend real, login e sincronização entre dispositivos.
- Rede social, permissões de compartilhamento e segurança remota.
- Widgets nativos do Android.
- 192 imagens individuais de exercícios (adiadas conforme orientação).

## Limitação importante sobre APK
Este pacote contém o código web recuperado do interior do APK, não o projeto Android nativo original nem um APK já compilado. O arquivo pode servir como base para um fluxo de empacotamento web/PWA, mas a compatibilidade exata com AndroidForge precisa ser confirmada. Recursos nativos (widgets) e serviços remotos exigem configuração e implementação próprias.

## Como testar a interface
Abra `index.html` em um navegador para uma verificação inicial. Para testar o service worker/PWA, hospede a pasta em um endereço HTTPS ou use um servidor local compatível; service workers não funcionam em todos os contextos `file://`.

## Próximos passos recomendados
1. Fazer backup dos dados da versão instalada antes de substituir qualquer aplicativo.
2. Importar este ZIP no fluxo de empacotamento que aceite projeto web, se compatível.
3. Testar a interface em Android antes de substituir a versão atual.
4. Implementar as funcionalidades pendentes por etapas, começando por banco de dados local estruturado e testes.
