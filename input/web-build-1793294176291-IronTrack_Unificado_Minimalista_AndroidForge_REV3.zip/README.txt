IRONTRACK — PACOTE WEB PARA ANDROIDFORGE

Este ZIP contém o projeto web com index.html na raiz, manifest.json, service worker e ícones em assets/.

IMPORTANTE: este pacote é um projeto web para ser importado pelo fluxo AndroidForge; não é um APK pronto nem inclui Gradle/Android nativo.

Correção desta revisão: o service worker não tenta mais pré-carregar uma imagem inexistente, que poderia falhar no cache offline. Os caminhos dos ícones foram conferidos.

Antes de substituir uma instalação existente, exporte um backup JSON. O app usa armazenamento local do aparelho; não há sincronização automática na nuvem.
