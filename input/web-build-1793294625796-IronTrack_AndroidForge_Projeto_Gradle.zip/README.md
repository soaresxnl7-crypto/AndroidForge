# IronTrack — AndroidForge project source

This ZIP is a Gradle Android application project, not an APK and not just a loose HTML folder.

## Project structure
- `settings.gradle` and root `build.gradle`: Gradle project configuration.
- `app/build.gradle`: Android application module.
- `app/src/main/AndroidManifest.xml`: app manifest.
- `app/src/main/java/com/irontrack/app/MainActivity.java`: Android WebView host.
- `app/src/main/assets/www/`: original IronTrack web application files extracted from the supplied ZIP.
- `reference/Painel-de-UI-15-telas.png`: the user's 15-screen design reference, preserved separately.

## Build
Open this folder as an Android/Gradle project or configure AndroidForge to use the ZIP's project root. The build requires Android SDK and internet access for Gradle plugin/dependency resolution.

## Important scope note
The provided `New Folder.zip` contained packaged app assets (`assets/www`) and APK metadata, not the original editable Android source project. This package adds the missing Gradle/Android shell around those web assets so Gradle has a real project to build. The 15-screen image is preserved as a reference; it is not automatically converted into 15 implemented screens by including the image.
