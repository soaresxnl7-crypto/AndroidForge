# IronTrack — interface minimalista e perfil inicial

Este pacote contém o projeto Android Gradle e os recursos web do IronTrack.

## Incluído
- Primeiro acesso exige nome e e-mail antes de mostrar o aplicativo.
- Perfil guardado localmente no aparelho; não há autenticação remota.
- Navegação inferior simplificada em quatro opções: Início, Buscar exercícios, Evolução e Perfil.
- Busca de exercícios e botão para adicionar exercício à ficha.
- Edição, exclusão e reordenação de exercícios; edição do nome da divisão/treino.
- Registro de séries, cargas, repetições, timer de descanso e cardio, histórico, estatísticas, calendário, superséries e backup manual.
- Treinos exemplo servem apenas como ficha inicial; o histórico começa sem treinos concluídos.

## Validação
ZIP verificado por integridade. Não foi possível confirmar uma compilação Android real nesta etapa; teste no AndroidForge antes de instalar. O cadastro é local, não sincroniza entre aparelhos.
