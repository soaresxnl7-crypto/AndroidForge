# IronTrack — pacote AndroidForge

Este ZIP contém um projeto Android Gradle real, com `settings.gradle` na raiz. Isso corrige a causa estrutural do erro anterior: o pacote anterior continha apenas arquivos de uma aplicação web dentro de `IronTrack_Pacote/`, sem arquivos Gradle, e por isso não podia ser compilado diretamente como projeto Android.

## Como compilar
- Android Gradle Plugin: 8.7.3
- Java: 17
- SDK de compilação: Android 35
- A tarefa `gradle bundleDebug` foi configurada para produzir o bundle de depuração e também o APK instalável.
- APK esperado: `app/build/outputs/apk/debug/app-debug.apk` (o nome pode incluir `.debug` devido ao sufixo de depuração; verifique o caminho de saída no log do workflow).
- AAB esperado: `app/build/outputs/bundle/debug/app-debug.aab`.

## Recursos incluídos na interface
- Identidade visual preto/vermelho e monograma IT em preto e branco.
- Tela inicial com saudação e animação curta.
- Fichas editáveis, biblioteca de exercícios, cargas, repetições, séries concluídas, reorganização e cronômetro.
- Histórico, gráfico de volume, calendário, medidas corporais e backup/restauração JSON.
- Notas por sessão e por exercício.
- Agrupamento de supersets na ficha atual.
- Recordes pessoais calculados a partir das cargas registradas no histórico.
- Templates locais para salvar e aplicar uma divisão de treino.
- Mapeamento de grupo muscular e dados guardados localmente para uso offline.

## Limitações que ainda exigem implementação/configuração
- Login real e sincronização na nuvem não estão ativos; os dados ficam neste aparelho até exportar/importar backup.
- Social/compartilhamento online não está implementado.
- Widgets nativos do Android não estão incluídos nesta versão.
- Ilustrações da biblioteca são representativas, não imagens anatômicas individuais.

## Importante
O APK ainda não foi compilado nem testado em dispositivo neste pacote. Use o AndroidForge para compilar e verifique o resultado do workflow antes de instalar. Guarde o ZIP original e faça backup dos dados da versão atual do app antes de substituir uma instalação.
