# IronTrack — requisitos consolidados e status desta versão

## Identidade e experiência
- Nome IRONTRACK.
- Monograma IT preto e branco no ícone e na interface.
- Tela de abertura curta, fundo preto, animação e saudação por horário/nome.
- Tema escuro preto/vermelho.

## Treino
- Divisão Push / Pull / Lower 1 / Upper / Lower 2, com divisão editável e quarta-feira de descanso configurada no planejamento semanal.
- Registro de séries concluídas, cargas e repetições.
- Cronômetro de descanso.
- Biblioteca de exercícios e pesquisa por exercício/grupo muscular.
- Reordenar e editar exercícios.
- Supersets: agrupamento de dois exercícios por divisão; os dados das séries permanecem separados.
- Notes: notas por exercício e por sessão.
- Muscles: indicação de grupo muscular principal estimado pelo nome do exercício.
- PR: recordes de carga calculados a partir do histórico registrado.
- Templates: salvar e aplicar modelos de ficha localmente.

## Progresso e dados
- Histórico de treinos, gráfico de volume, calendário e medidas corporais.
- Exportação/importação de backup JSON, incluindo templates, notas e supersets.
- Armazenamento local para uso offline.

## Dependências ainda necessárias para recursos conectados/nativos
- Nuvem/autenticação: selecionar e configurar backend (ex.: Supabase ou Firebase), credenciais, regras de segurança/RLS e sincronização/conflitos.
- Social: depende de backend, perfis, regras de privacidade, denúncias/moderação e compartilhamento consentido.
- Widgets Android: requer implementação nativa Android (AppWidgetProvider/RemoteViews), testes de atualização e compatibilidade.
- Imagens anatômicas individuais: adiadas; as ilustrações atuais são genéricas/representativas.

## Build
- O ZIP tem `settings.gradle` e `build.gradle` na raiz para ser extraído diretamente como raiz Gradle.
- Projeto Android com WebView que carrega a interface local incluída em `app/src/main/assets/www/`.
- A tarefa agregadora `gradle bundleDebug` solicita o AAB e também `assembleDebug` para gerar APK.
- A compilação final precisa ser confirmada no AndroidForge; esta entrega ainda não é um APK testado.
