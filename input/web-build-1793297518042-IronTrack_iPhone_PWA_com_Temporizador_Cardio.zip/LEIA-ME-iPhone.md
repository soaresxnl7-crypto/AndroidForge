# IronTrack para iPhone — PWA

Este pacote contém a versão web instalável do IronTrack IT Edition, incluindo o temporizador de cardio. Não é um arquivo IPA e não precisa de App Store para ser usado como atalho na Tela de Início.

## Como colocar no iPhone
1. Publique os arquivos deste ZIP em um serviço de hospedagem estática com HTTPS (por exemplo, GitHub Pages). Mantenha `index.html`, `manifest.json`, `sw.js` e a pasta `assets` no mesmo diretório.
2. Abra o endereço HTTPS publicado no Safari do iPhone.
3. Toque em Compartilhar → Adicionar à Tela de Início → Adicionar.
4. Abra o IronTrack pelo ícone criado na Tela de Início.

## O que está incluído
- Edição leve IT, sem imagens individuais dos exercícios.
- Treinos, histórico, cargas, gráficos, perfil e temporizador de descanso.
- Temporizador de cardio com duração configurável, atalhos, iniciar/pausar e reiniciar.
- Ícone e configuração para instalação pela Tela de Início do iPhone.
- Cache offline básico após a primeira abertura bem-sucedida.

## Importante sobre os dados
Os dados ficam armazenados localmente no navegador/aparelho. Não há sincronização automática entre iPhone e Android. Use a função de backup/restauração do aplicativo para transferir dados manualmente, se necessário. Evite limpar os dados do Safari ou remover os dados do site se quiser preservar registros.

Este ZIP é o pacote web pronto para hospedagem, não um aplicativo iOS assinado pela App Store.
